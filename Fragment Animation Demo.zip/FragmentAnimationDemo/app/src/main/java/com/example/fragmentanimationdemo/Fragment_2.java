package com.example.fragmentanimationdemo;

import androidx.fragment.app.Fragment;

public class Fragment_2 extends Fragment {
}
