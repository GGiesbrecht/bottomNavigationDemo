package com.example.fragmentanimationdemo;

import androidx.fragment.app.Fragment;

public class Fragment_1 extends Fragment {
}
